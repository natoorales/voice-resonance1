<?php
/**
 * Placeholder for Stripe service
 * This will be fully implemented later.
 */

class VR_Stripe {
    // Placeholder
}